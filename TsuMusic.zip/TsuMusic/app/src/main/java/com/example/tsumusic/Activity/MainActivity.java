package com.example.tsumusic.Activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.example.tsumusic.Adapter.Adapter_ViewPager;
import com.example.tsumusic.Fragment.Fragment_Main;
import com.example.tsumusic.Fragment.Fragment_Search;
import com.example.tsumusic.R;
import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity {

    TabLayout tabLayout;
    ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mapping();
        init();
    }

    private void init() {
        Adapter_ViewPager adapter_viewPager = new Adapter_ViewPager(getSupportFragmentManager());
        adapter_viewPager.addFragment(new Fragment_Main(), "Trang Chủ");
        adapter_viewPager.addFragment(new Fragment_Search(),"Tìm Kiếm";
        viewPager.setAdapter(adapter_viewPager);
        tabLayout.setupWithViewPager(viewPager);
        tabLayout.getTabAt(0).setIcon()
    }

    private void mapping(){          //Ánh xạ
        tabLayout = findViewById(R.id.mainTabLayout);
        viewPager = findViewById(R.id.mainViewPager);
    }
}